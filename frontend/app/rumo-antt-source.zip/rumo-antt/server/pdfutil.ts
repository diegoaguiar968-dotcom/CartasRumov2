import { execFileSync } from "child_process";
import fs from "fs";
import path from "path";

/**
 * Extract text from a PDF file using pdfplumber (Python).
 * Robust and handles all common PDF types.
 */
export async function extractPdfText(filePath: string): Promise<string> {
  const absPath = path.resolve(filePath);

  // Inline Python script — no temp file needed
  const pythonScript = `
import sys, pdfplumber
try:
    with pdfplumber.open(sys.argv[1]) as pdf:
        pages = []
        for page in pdf.pages:
            t = page.extract_text()
            if t:
                pages.append(t)
        print('\\n\\n'.join(pages))
except Exception as e:
    print(f'ERRO: {e}', file=sys.stderr)
    sys.exit(1)
`;

  try {
    const result = execFileSync("python3", ["-c", pythonScript, absPath], {
      encoding: "utf8",
      timeout: 30000,
      maxBuffer: 10 * 1024 * 1024, // 10MB
    });
    return result.trim();
  } catch (err: any) {
    // Fallback: try to read raw text if Python fails
    const stderr = err.stderr || "";
    throw new Error(`Falha ao extrair texto do PDF: ${stderr || err.message}`);
  }
}
