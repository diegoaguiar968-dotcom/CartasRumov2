import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  AlignmentType,
  HeadingLevel,
  BorderStyle,
  Footer,
  Header,
  PageNumber,
  NumberFormat,
  TabStopPosition,
  TabStopType,
} from "docx";
import { PDFDocument, StandardFonts, rgb, PageSizes } from "pdf-lib";

interface DocOptions {
  signatario: string;
  cargo: string;
  oficioNumero: string;
}

// Rumo brand colors
const RUMO_AZUL = "003865";
const RUMO_AZUL_CLARO = "32A6E6";
const RUMO_VERDE = "1E9F7F";

/**
 * Generate a DOCX file from minuta text, styled with Rumo branding
 */
export async function generateDocx(minutaText: string, options: DocOptions): Promise<Buffer> {
  const lines = minutaText.split("\n").filter((l) => l.trim() !== "");

  const bodyParagraphs: Paragraph[] = [];

  for (const line of lines) {
    const trimmed = line.trim();

    // Detect section headers (all caps or starts with number/roman)
    const isHeader =
      /^[A-ZÁÉÍÓÚÂÊÔÃÕÇ\s]{10,}$/.test(trimmed) ||
      /^\d+[\.\)]\s/.test(trimmed) ||
      /^(ASSUNTO|DESTINATÁRIO|REFERÊNCIA|SENHOR|SENHORA|AO SENHOR|À SENHORA)/i.test(trimmed);

    if (isHeader) {
      bodyParagraphs.push(
        new Paragraph({
          spacing: { before: 240, after: 120 },
          children: [
            new TextRun({
              text: trimmed,
              font: "Verdana",
              size: 22, // 11pt
              bold: true,
              color: RUMO_AZUL,
            }),
          ],
        })
      );
    } else {
      bodyParagraphs.push(
        new Paragraph({
          spacing: { after: 120 },
          alignment: AlignmentType.JUSTIFIED,
          children: [
            new TextRun({
              text: trimmed,
              font: "Verdana",
              size: 20, // 10pt
            }),
          ],
        })
      );
    }
  }

  const doc = new Document({
    styles: {
      default: {
        document: {
          run: {
            font: "Verdana",
            size: 20,
          },
        },
      },
    },
    sections: [
      {
        properties: {
          page: {
            margin: {
              top: 1800,
              right: 1200,
              bottom: 1400,
              left: 1200,
            },
          },
        },
        headers: {
          default: new Header({
            children: [
              // Rumo header line
              new Paragraph({
                spacing: { after: 100 },
                children: [
                  new TextRun({
                    text: "RUMO LOGÍSTICA OPERADORA MULTIMODAL S.A.",
                    font: "Verdana",
                    size: 18,
                    bold: true,
                    color: RUMO_AZUL,
                  }),
                ],
              }),
              // Divider
              new Paragraph({
                border: {
                  bottom: {
                    style: BorderStyle.SINGLE,
                    size: 6,
                    color: RUMO_AZUL_CLARO,
                  },
                },
                spacing: { after: 200 },
                children: [
                  new TextRun({
                    text: "Relações Institucionais / Regulatório",
                    font: "Verdana",
                    size: 14,
                    color: "666666",
                  }),
                ],
              }),
            ],
          }),
        },
        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                border: {
                  top: {
                    style: BorderStyle.SINGLE,
                    size: 4,
                    color: RUMO_AZUL_CLARO,
                  },
                },
                spacing: { before: 100 },
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({
                    text: "Rumo Logística Operadora Multimodal S.A. | CNPJ 71.550.388/0001-42",
                    font: "Verdana",
                    size: 12,
                    color: "888888",
                  }),
                ],
              }),
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({
                    text: "Av. Brigadeiro Faria Lima, 4100 – 15º andar – São Paulo/SP – CEP 04538-132",
                    font: "Verdana",
                    size: 12,
                    color: "888888",
                  }),
                ],
              }),
            ],
          }),
        },
        children: bodyParagraphs,
      },
    ],
  });

  const buffer = await Packer.toBuffer(doc);
  return Buffer.from(buffer);
}

/**
 * Generate a PDF directly from minuta text with Rumo branding
 */
export async function generatePdfFromDocx(minutaText: string, options: DocOptions): Promise<Buffer> {
  const pdfDoc = await PDFDocument.create();
  const helvetica = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const helveticaBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

  const pageWidth = PageSizes.A4[0]; // 595.28
  const pageHeight = PageSizes.A4[1]; // 841.89
  const margin = 60;
  const contentWidth = pageWidth - margin * 2;
  const lineHeight = 14;
  const headerHeight = 70;
  const footerHeight = 50;

  // Color conversions
  const azul = rgb(0 / 255, 56 / 255, 101 / 255);
  const azulClaro = rgb(50 / 255, 166 / 255, 230 / 255);
  const cinza = rgb(0.4, 0.4, 0.4);
  const preto = rgb(0.15, 0.15, 0.15);

  const lines = minutaText.split("\n").filter((l) => l.trim() !== "");

  // Word wrap function
  function wrapText(text: string, font: any, fontSize: number, maxWidth: number): string[] {
    const words = text.split(" ");
    const lines: string[] = [];
    let currentLine = "";

    for (const word of words) {
      const testLine = currentLine ? `${currentLine} ${word}` : word;
      const width = font.widthOfTextAtSize(testLine, fontSize);
      if (width > maxWidth && currentLine) {
        lines.push(currentLine);
        currentLine = word;
      } else {
        currentLine = testLine;
      }
    }
    if (currentLine) lines.push(currentLine);
    return lines;
  }

  let page = pdfDoc.addPage(PageSizes.A4);
  let y = pageHeight - margin - headerHeight;

  function drawHeader(pg: any) {
    // Blue header bar
    pg.drawRectangle({
      x: 0,
      y: pageHeight - 55,
      width: pageWidth,
      height: 55,
      color: azul,
    });
    // Accent line below
    pg.drawRectangle({
      x: 0,
      y: pageHeight - 59,
      width: pageWidth,
      height: 4,
      color: azulClaro,
    });
    // Company name
    pg.drawText("RUMO LOGÍSTICA OPERADORA MULTIMODAL S.A.", {
      x: margin,
      y: pageHeight - 30,
      size: 10,
      font: helveticaBold,
      color: rgb(1, 1, 1),
    });
    pg.drawText("Relações Institucionais / Regulatório", {
      x: margin,
      y: pageHeight - 44,
      size: 7.5,
      font: helvetica,
      color: rgb(0.8, 0.88, 0.95),
    });
  }

  function drawFooter(pg: any) {
    pg.drawRectangle({
      x: margin,
      y: 40,
      width: contentWidth,
      height: 0.5,
      color: azulClaro,
    });
    pg.drawText(
      "Rumo Logística Operadora Multimodal S.A. | CNPJ 71.550.388/0001-42 | Av. Brigadeiro Faria Lima, 4100 – 15º andar – São Paulo/SP",
      {
        x: margin,
        y: 28,
        size: 6,
        font: helvetica,
        color: cinza,
      }
    );
  }

  drawHeader(page);
  drawFooter(page);

  for (const line of lines) {
    const trimmed = line.trim();
    const isHeader =
      /^[A-ZÁÉÍÓÚÂÊÔÃÕÇ\s]{10,}$/.test(trimmed) ||
      /^\d+[\.\)]\s/.test(trimmed) ||
      /^(ASSUNTO|DESTINATÁRIO|REFERÊNCIA|SENHOR|SENHORA|AO SENHOR|À SENHORA)/i.test(trimmed);

    const font = isHeader ? helveticaBold : helvetica;
    const fontSize = isHeader ? 10 : 9;
    const color = isHeader ? azul : preto;

    const wrappedLines = wrapText(trimmed, font, fontSize, contentWidth);

    // Check if we need a new page
    const needed = wrappedLines.length * lineHeight + (isHeader ? 8 : 0);
    if (y - needed < margin + footerHeight) {
      page = pdfDoc.addPage(PageSizes.A4);
      y = pageHeight - margin - headerHeight;
      drawHeader(page);
      drawFooter(page);
    }

    if (isHeader) y -= 8; // extra spacing before headers

    for (const wl of wrappedLines) {
      page.drawText(wl, {
        x: margin,
        y,
        size: fontSize,
        font,
        color,
      });
      y -= lineHeight;
    }

    y -= 4; // paragraph spacing
  }

  const pdfBytes = await pdfDoc.save();
  return Buffer.from(pdfBytes);
}
