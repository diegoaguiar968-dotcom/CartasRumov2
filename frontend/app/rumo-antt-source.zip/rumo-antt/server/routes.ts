import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import fs from "fs";
import Anthropic from "@anthropic-ai/sdk";
import { generateDocx, generatePdfFromDocx } from "./docgen";
import { extractPdfText } from "./pdfutil";
import { log } from "./index";

// Multer config — store in /tmp
const upload = multer({
  dest: "/tmp/uploads",
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (_req, file, cb) => {
    if (file.mimetype === "application/pdf" || file.originalname.endsWith(".pdf")) {
      cb(null, true);
    } else {
      cb(new Error("Apenas arquivos PDF são aceitos."));
    }
  },
});

// Anthropic client (uses env vars injected by api_credentials)
const anthropic = new Anthropic();

// In-memory state per visitor
interface VisitorState {
  modelTexts: string[];
  modelPatterns: string | null;
  oficioText: string | null;
  oficioBriefing: any | null;
  minutaText: string | null;
}

const visitors = new Map<string, VisitorState>();

function getVisitor(req: Request): VisitorState {
  const vid = (req.headers["x-visitor-id"] as string) || "default";
  if (!visitors.has(vid)) {
    visitors.set(vid, {
      modelTexts: [],
      modelPatterns: null,
      oficioText: null,
      oficioBriefing: null,
      minutaText: null,
    });
  }
  return visitors.get(vid)!;
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // ──────────────────────────────────────────────
  // STEP 1: Upload model PDFs and analyze patterns
  // ──────────────────────────────────────────────
  app.post("/api/models/upload", upload.array("files", 20), async (req: Request, res: Response) => {
    try {
      const files = req.files as Express.Multer.File[];
      if (!files || files.length === 0) {
        return res.status(400).json({ message: "Nenhum arquivo enviado." });
      }

      const visitor = getVisitor(req);
      const results: { name: string; pages: number }[] = [];

      for (const file of files) {
        const text = await extractPdfText(file.path);
        visitor.modelTexts.push(text);
        results.push({
          name: file.originalname,
          pages: text.split("\n\n").length, // rough page estimate
        });
        // Clean up temp file
        fs.unlink(file.path, () => {});
      }

      res.json({
        message: `${files.length} arquivo(s) processado(s).`,
        files: results,
      });
    } catch (err: any) {
      log(`Error uploading models: ${err.message}`);
      res.status(400).json({ message: err.message });
    }
  });

  // ──────────────────────────────────────────────
  // STEP 1b: Analyze patterns from uploaded models
  // ──────────────────────────────────────────────
  app.post("/api/models/analyze", async (req: Request, res: Response) => {
    try {
      const visitor = getVisitor(req);
      if (visitor.modelTexts.length === 0) {
        return res.status(400).json({ message: "Nenhum modelo carregado. Faça upload dos PDFs primeiro." });
      }

      const combinedModels = visitor.modelTexts
        .map((t, i) => `=== MODELO ${i + 1} ===\n${t}`)
        .join("\n\n");

      const response = await anthropic.messages.create({
        model: "claude_sonnet_4_6",
        max_tokens: 4096,
        messages: [{
          role: "user",
          content: `Você é um analista especializado em comunicação institucional da Rumo Logística com a ANTT.

Analise os documentos-modelo abaixo e extraia os padrões de linguagem, estrutura e formatação.

Retorne um resumo estruturado em português com:
1. Estrutura de abertura (saudação, referência ao ofício)
2. Estrutura do corpo (como respondem aos pontos)
3. Estrutura de encerramento (fórmula de cortesia, assinatura)
4. Tom e registro linguístico (formal/informal, tratamento usado)
5. Vocabulário técnico-jurídico recorrente
6. Expressões e fórmulas de cortesia padrão
7. Padrão de numeração e referência dos ofícios Rumo

DOCUMENTOS MODELO:
${combinedModels.substring(0, 60000)}`
        }],
      });

      const patterns = response.content[0].type === "text" ? response.content[0].text : "";
      visitor.modelPatterns = patterns;

      res.json({ patterns });
    } catch (err: any) {
      log(`Error analyzing models: ${err.message}`);
      res.status(422).json({ message: `Erro ao analisar modelos: ${err.message}` });
    }
  });

  // ──────────────────────────────────────────────
  // STEP 2: Upload ofício and extract briefing
  // ──────────────────────────────────────────────
  app.post("/api/oficio/upload", upload.single("file"), async (req: Request, res: Response) => {
    try {
      const file = req.file;
      if (!file) {
        return res.status(400).json({ message: "Nenhum arquivo enviado." });
      }

      const visitor = getVisitor(req);
      const text = await extractPdfText(file.path);
      visitor.oficioText = text;
      fs.unlink(file.path, () => {});

      // Use LLM to extract structured briefing
      const response = await anthropic.messages.create({
        model: "claude_sonnet_4_6",
        max_tokens: 4096,
        messages: [{
          role: "user",
          content: `Você é um analista regulatório da Rumo Logística. Analise o ofício abaixo, recebido da ANTT, e extraia as informações em formato JSON.

Retorne APENAS um JSON válido, sem markdown ou texto adicional, com esta estrutura:
{
  "numero": "número/referência do ofício",
  "data": "data do ofício",
  "signatarioAntt": "nome e cargo do signatário",
  "area": "superintendência ou gerência da ANTT",
  "prazo": "prazo de resposta mencionado ou 'Não especificado'",
  "natureza": "tipo da solicitação (informações, esclarecimentos, documentos, etc.)",
  "fundamentoLegal": "norma ou resolução citada, ou 'Não citado'",
  "pontos": ["ponto 1 a responder", "ponto 2 a responder", ...],
  "documentosRequisitados": ["documento 1", "documento 2", ...]
}

OFÍCIO:
${text.substring(0, 30000)}`
        }],
      });

      const rawText = response.content[0].type === "text" ? response.content[0].text : "{}";

      // Extract JSON from response (handle potential markdown wrapping)
      let jsonStr = rawText;
      const jsonMatch = rawText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        jsonStr = jsonMatch[0];
      }

      const briefing = JSON.parse(jsonStr);
      visitor.oficioBriefing = briefing;

      res.json({ briefing });
    } catch (err: any) {
      log(`Error processing oficio: ${err.message}`);
      res.status(422).json({ message: `Erro ao processar ofício: ${err.message}` });
    }
  });

  // ──────────────────────────────────────────────
  // STEP 3: Generate minuta from data
  // ──────────────────────────────────────────────
  app.post("/api/minuta/generate", async (req: Request, res: Response) => {
    try {
      const visitor = getVisitor(req);
      const { signatario, cargo, pontos } = req.body;

      if (!visitor.oficioBriefing) {
        return res.status(400).json({ message: "Nenhum ofício carregado. Faça upload na Etapa 2." });
      }

      const briefing = visitor.oficioBriefing;
      const patternsContext = visitor.modelPatterns
        ? `\nPADRÕES IDENTIFICADOS NAS CARTAS-MODELO DA RUMO:\n${visitor.modelPatterns}\n`
        : "";

      const pontosText = (pontos || [])
        .map((p: any, i: number) => `Ponto ${i + 1}:\nPergunta ANTT: ${p.pergunta}\nDados para resposta: ${p.resposta}`)
        .join("\n\n");

      const today = new Date().toLocaleDateString("pt-BR", {
        day: "numeric",
        month: "long",
        year: "numeric",
      });

      const response = await anthropic.messages.create({
        model: "claude_sonnet_4_6",
        max_tokens: 8192,
        messages: [{
          role: "user",
          content: `Você é o redator institucional da Rumo Logística Operadora Multimodal S.A., especializado em respostas a ofícios da ANTT.

Redija a minuta completa de resposta ao ofício da ANTT descrito abaixo, seguindo rigorosamente o padrão institucional da Rumo.
${patternsContext}

OFÍCIO DA ANTT:
- Número: ${briefing.numero}
- Data: ${briefing.data}
- Signatário ANTT: ${briefing.signatarioAntt}
- Área: ${briefing.area}
- Prazo: ${briefing.prazo}
- Natureza: ${briefing.natureza}
- Fundamento legal: ${briefing.fundamentoLegal}

DADOS FORNECIDOS PELA RUMO PARA RESPONDER CADA PONTO:
${pontosText || "(Nenhum dado fornecido — redigir estrutura com placeholders)"}

SIGNATÁRIO DA RESPOSTA:
Nome: ${signatario || "[NOME DO SIGNATÁRIO]"}
Cargo: ${cargo || "[CARGO]"}

DATA DA RESPOSTA: São Paulo, ${today}

INSTRUÇÕES DE REDAÇÃO:
1. Use tom formal técnico-jurídico
2. Tratamento: "Vossa Senhoria" para diretores/superintendentes ANTT
3. Abertura: referência ao ofício recebido com número e data
4. Corpo: responda cada ponto numerado com clareza e precisão
5. Cite o contrato de concessão e normas quando pertinente
6. Encerramento: disposição para esclarecimentos + "Atenciosamente,"
7. Assinatura ao final
8. Parágrafos curtos e objetivos
9. Nunca invente dados que não foram fornecidos — use placeholders [INSERIR DADO] quando faltar informação

Redija a minuta completa agora:`
        }],
      });

      const minutaText = response.content[0].type === "text" ? response.content[0].text : "";
      visitor.minutaText = minutaText;

      res.json({ minuta: minutaText });
    } catch (err: any) {
      log(`Error generating minuta: ${err.message}`);
      res.status(422).json({ message: `Erro ao gerar minuta: ${err.message}` });
    }
  });

  // ──────────────────────────────────────────────
  // STEP 4: Generate DOCX file
  // ──────────────────────────────────────────────
  app.post("/api/export/docx", async (req: Request, res: Response) => {
    try {
      const visitor = getVisitor(req);
      if (!visitor.minutaText) {
        return res.status(400).json({ message: "Nenhuma minuta gerada." });
      }

      const { signatario, cargo } = req.body;
      const briefing = visitor.oficioBriefing;
      const numero = briefing?.numero || "XXX";

      const docxBuffer = await generateDocx(visitor.minutaText, {
        signatario: signatario || "",
        cargo: cargo || "",
        oficioNumero: numero,
      });

      const filename = `OF.RUMO_Resposta_ANTT_${numero.replace(/[/\\]/g, "_")}_${new Date().toISOString().split("T")[0]}.docx`;

      res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      res.send(Buffer.from(docxBuffer));
    } catch (err: any) {
      log(`Error generating docx: ${err.message}`);
      res.status(422).json({ message: `Erro ao gerar DOCX: ${err.message}` });
    }
  });

  // ──────────────────────────────────────────────
  // STEP 4: Generate PDF file
  // ──────────────────────────────────────────────
  app.post("/api/export/pdf", async (req: Request, res: Response) => {
    try {
      const visitor = getVisitor(req);
      if (!visitor.minutaText) {
        return res.status(400).json({ message: "Nenhuma minuta gerada." });
      }

      const { signatario, cargo } = req.body;
      const briefing = visitor.oficioBriefing;
      const numero = briefing?.numero || "XXX";

      const pdfBuffer = await generatePdfFromDocx(visitor.minutaText, {
        signatario: signatario || "",
        cargo: cargo || "",
        oficioNumero: numero,
      });

      const filename = `OF.RUMO_Resposta_ANTT_${numero.replace(/[/\\]/g, "_")}_${new Date().toISOString().split("T")[0]}.pdf`;

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      res.send(Buffer.from(pdfBuffer));
    } catch (err: any) {
      log(`Error generating pdf: ${err.message}`);
      res.status(422).json({ message: `Erro ao gerar PDF: ${err.message}` });
    }
  });

  // ──────────────────────────────────────────────
  // Get current state
  // ──────────────────────────────────────────────
  app.get("/api/state", (req: Request, res: Response) => {
    const visitor = getVisitor(req);
    res.json({
      hasModels: visitor.modelTexts.length > 0,
      modelCount: visitor.modelTexts.length,
      modelPatterns: visitor.modelPatterns,
      hasOficio: !!visitor.oficioText,
      oficioBriefing: visitor.oficioBriefing,
      hasMinuta: !!visitor.minutaText,
      minutaText: visitor.minutaText,
    });
  });

  // Reset state
  app.post("/api/reset", (req: Request, res: Response) => {
    const vid = (req.headers["x-visitor-id"] as string) || "default";
    visitors.delete(vid);
    res.json({ message: "Estado resetado." });
  });

  return httpServer;
}
