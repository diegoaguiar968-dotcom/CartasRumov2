import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Keep users table for template compatibility
export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Briefing structure returned from LLM analysis
export interface OficioBriefing {
  numero: string;
  data: string;
  signatarioAntt: string;
  area: string;
  prazo: string;
  natureza: string;
  fundamentoLegal: string;
  pontos: string[];
  documentosRequisitados: string[];
}

// Session data for the frontend
export interface SessionData {
  modelPatterns: string | null;
  oficioBriefing: OficioBriefing | null;
  minutaText: string | null;
}
