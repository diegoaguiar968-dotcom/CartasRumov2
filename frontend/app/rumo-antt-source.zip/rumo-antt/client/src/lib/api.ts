import { apiRequest } from "./queryClient";

// Upload model PDFs
export async function uploadModels(files: File[]): Promise<{ message: string; files: { name: string; pages: number }[] }> {
  const form = new FormData();
  files.forEach(f => form.append("files", f));
  
  const res = await fetch("/api/models/upload", {
    method: "POST",
    body: form,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: "Erro ao enviar arquivos" }));
    throw new Error(err.message);
  }
  return res.json();
}

// Analyze model patterns
export async function analyzeModels(): Promise<{ patterns: string }> {
  const res = await apiRequest("POST", "/api/models/analyze");
  return res.json();
}

// Upload ofício PDF
export async function uploadOficio(file: File): Promise<{ briefing: any }> {
  const form = new FormData();
  form.append("file", file);
  
  const res = await fetch("/api/oficio/upload", {
    method: "POST",
    body: form,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: "Erro ao processar ofício" }));
    throw new Error(err.message);
  }
  return res.json();
}

// Generate minuta
export async function generateMinuta(data: {
  signatario: string;
  cargo: string;
  pontos: { pergunta: string; resposta: string }[];
}): Promise<{ minuta: string }> {
  const res = await apiRequest("POST", "/api/minuta/generate", data);
  return res.json();
}

// Download DOCX
export async function downloadDocx(signatario: string, cargo: string): Promise<void> {
  const res = await fetch("/api/export/docx", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ signatario, cargo }),
  });
  if (!res.ok) throw new Error("Erro ao gerar DOCX");
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = res.headers.get("Content-Disposition")?.match(/filename="(.+)"/)?.[1] || "resposta.docx";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Download PDF
export async function downloadPdf(signatario: string, cargo: string): Promise<void> {
  const res = await fetch("/api/export/pdf", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ signatario, cargo }),
  });
  if (!res.ok) throw new Error("Erro ao gerar PDF");
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = res.headers.get("Content-Disposition")?.match(/filename="(.+)"/)?.[1] || "resposta.pdf";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Get current state
export async function getState(): Promise<any> {
  const res = await apiRequest("GET", "/api/state");
  return res.json();
}
